// LA  ENTRADA 
//  COMIENZA CON UN  NUMERO  INDICANDO  CUANTOS CASOS  DE  PRUEBA DEBERAN  SER  PROCESADOS.
//CADA UNO  ES UN NUMERO ENTRE  1 Y  10.000
//***  SALIDA***
//POR  CADA CASO  EL PROGRAMA ESCRIBIRA  EL SIGLO AL  QUE PERTENECE EL  AÑP DE ÑA ENTRADA.
//SE ESCRIBE  CON  NUMEROS NORMALES   EN LÑUGAR DE NUMEROS ROMANOS 

/**
 *El siglo XVI COMPRENDIO LOS AÑOS DESDE  EL 1501 AL 1600 
 * EL SIGLO XXI EMPIEZA EN EL  2001  CON  UN  20   Y  EN  SUS  DOS PRIMEROS  DIGITOS  Y NO  UN  21.
 * 
 */

package Ejercicios2;

import java.util.Scanner;


public class Ejercicio1 {

    
    public static void main(String[] args) {
          
     
            System.out.println("dime cuantos casos seran procesados:");//  le pido al usuario que me de un numero 
            Scanner sc = new Scanner(System.in);
            int casos = sc.nextInt();
            int[] ano = new int[casos];

            System.out.println("Introduce  numeros de 1 a 10000"); //  le pideo  que me de el  siguente de cada numero  entre 1 y 10000
            System.out.println("*******ENTRADA*****:"); //  vemos  la entrada de los numeros 
            for (int i = 0; i < ano.length; i++) {
                ano[i] = sc.nextInt();
            }

            System.out.println("*******SALIDA*******"); //  la salida  de cuyos numeros 
            for (int i = 0; i < ano.length; i++) {
                String an = ano[i] + "";
                char an1 = an.charAt(0);
                char an2 = an.charAt(1);
                String sig = "" + an1 + an2;
                int siglo = Integer.parseInt(sig) + 1;
                System.out.println(siglo);
            }
        }

    }

    
       