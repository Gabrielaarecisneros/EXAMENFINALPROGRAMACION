/*
 * medice   que cada  lila corresponde  a  una  farola  o unidad  lumino --- TIPOS DE FAROLA ---  DISTRITO SE ENCUENTRAN---
 * UNIDAD LUMINOSA CUANQUIER  SOPORTE QUE NOS DA LUZ  CON  DEL  NUMERO   DE LAMPARAS O  ELEMENTOS LESDS
 * soporte que nos de luz con independencia del numero de  lamparas   o  elementos leds
 *(TIPOS LUMINOSOS//++LED++DESCARGA++ Y LED-DESCARGA 
//RESUMEN DE  TODOS LAS FOAROLAS  !!!!!
DE QUE TIPO HAY  MAS FAROLAS  Y  CUANTAS ??? 
//CUANTAS  HAY POR CADA DISTRITO
//CUANTAS FAROLAS HAY DE MEDIA EN MADRID  
 */
package Examen;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;



public class Ejercicio2 {

	
	 static ArrayList<String[]> datosDistritos = new ArrayList<>();
	 static ArrayList<String[]> datosFarolas = new ArrayList<>();

	public static void cargarDatos(File fichero, int nColumnas,ArrayList<String[]> dondeSeGuarda) {
		
		
		try {
                    try (Scanner lector = new Scanner(fichero).useDelimiter(";|\n")) {
                        for(int i=0; i<nColumnas;i++){ //Este FOR es para recorrer la primera li­nea de cada archivo sin guardarla.
                            lector.next();
                        }
                        do{
                            String datosPorLinea[]=new String[nColumnas];
                            for(int i=0; i<datosPorLinea.length;i++){
                                datosPorLinea[i]=lector.next();
                                //System.out.println(i+" --> "+datosPorLinea[i]);
                            }
                            dondeSeGuarda.add(datosPorLinea);
                        }while(lector.hasNextLine());
                    }
		} catch (FileNotFoundException e) {
                    // TODO Bloque catch generado automáticamente

		}catch(Exception e) {
		}
	}
	
	public static void tipoyTotalFarolasMadrid() {
		//Hay tres tipos de farolas led, Descarga o Led-Descarga
		int contadorLed=0, contadorDescarga=0, contadorLedDescarga=0;
		for(String[]aux: datosFarolas) {
                    for (String aux1 : aux) {
                        switch (aux[1]) {
                            case "LED":
                                contadorLed++;
                                break;
                            case "DESCARGA":
                                contadorDescarga++;
                                break;
                            case "LED-DESCARGA":
                                contadorLedDescarga++;
                                break;
                            default:
                                break;
                        }
                    }
		}
		if(contadorLed>contadorDescarga && contadorLed>contadorLedDescarga) {
			System.out.println("Hay mas farolas de tipo LED con un total de "+contadorLed+" farolas.");
		}else if(contadorDescarga>contadorLed && contadorDescarga>contadorLedDescarga){
			System.out.println("Hay mas farolas de tipo DESCARGA con un total de "+contadorDescarga+" farolas.");

		}else if(contadorLedDescarga>contadorDescarga && contadorLedDescarga>contadorLed) {
			System.out.println("Hay mas farolas de tipo LED-DESCARGA con un total de "+contadorDescarga+" farolas.");
		}
	}
	
	public static void ResumenFarolas() {
		//no consigo leer el archivo distritos.csv asi que me guiare por el numero qeu tiene cada distrito en el otro fichero
		
		int []contadores= new int[21];
		
		for(String[]aux: datosFarolas) {
			int distrito= Integer.parseInt(aux[8]);//en la pos 8 es donde esta el numero del distrito
			contadores[distrito-1]++;//pos distrito-1 porque va de 0 a 20
		}
		int mayor=0;
		int pos=0;
		for (pos = 1; pos < contadores.length; pos++) {
			if (contadores[pos] > mayor) {
				mayor = contadores[pos];			
			}
		}
		System.out.println("El el distrito con mayor numero de farolas es: " + pos + " con "+ mayor + " farolas.");
		//pongo el distrito con el numero ya que no he podido leer el otro fichero
	}
	
	public static void mediaFarolasDistrito() {
		//estoy leyendo mal los ficheros pero voy a hacer el codigo como seria si tuviese los datos bien
		//la media se haria teniendo el total de farolas de cada distrito y dividiendo la suma de todos esos numeros por el total de distritos(21)
		
		int []contadores= new int[21];
		for(String[]aux: datosFarolas) {
			int distrito= Integer.parseInt(aux[8]);//en la pos 8 es donde esta el numero del distrito
			contadores[distrito-1]++;//pos distrito-1 porque va de 0 a 20
		}
		int media=0;
		for(int i =0; i<contadores.length;i++) {
			media=+contadores[i];
		}
		media=media/21;
		System.out.println("EL numero de farolas medio por distrito es de "+ media+ " farolas.");
	}
	
	public static void main(String[] args) {
		
		File ficheroDistritos= new File("Distritos.csv");
		File ficheroFarolas= new File("20220408_DATOS_ABIERTOS_UNIDAD_LUMINOSA_.csv");
		
		cargarDatos(ficheroDistritos,8,datosDistritos);
		cargarDatos(ficheroFarolas,12,datosFarolas);
		tipoyTotalFarolasMadrid();
		ResumenFarolas();
		mediaFarolasDistrito();
	}

}

